package com.company;

import base.SequentialMatrix;

public class Main {

    public static void main(String[] args) {
	// write your code here

        //Primer Par De Matrices
        SequentialMatrix M1 = new SequentialMatrix(3,3);
        SequentialMatrix M2 = new SequentialMatrix(3,3);
        long start = System.nanoTime();
        double[][] multi1 = M1.multiply(M2);
        long end = System.nanoTime();
        double dif = (double)(end - start);

        //Segundo Par de Matrices
        SequentialMatrix M3 = new SequentialMatrix(7,7);
        SequentialMatrix M4 = new SequentialMatrix(7,7);
        long start2 = System.nanoTime();
        double[][] multi2 = M3.multiply(M4);
        long end2 = System.nanoTime();
        double dif2 = (double)(end2 - start2);


        //Tercer par de matrices
        SequentialMatrix M5 = new SequentialMatrix(25,25);
        SequentialMatrix M6 = new SequentialMatrix(25,25);
        long start3 = System.nanoTime();
        double[][] multi3 = M5.multiply(M6);
        long end3 = System.nanoTime();
        double dif3 = (double)(end3 - start3);

        //Cuarto Par de Matrices
        SequentialMatrix M7 = new SequentialMatrix(100,100);
        SequentialMatrix M8 = new SequentialMatrix(100,100);
        long start4 = System.nanoTime();
        double[][] multi4 = M7.multiply(M8);
        long end4 = System.nanoTime();
        double dif4 = (double)(end4 - start4);




        //Primera Inversa
        SequentialMatrix Prueba = new SequentialMatrix(100,100);
        long entrada1 = System.nanoTime();
        Prueba.Inversa();
        long salida1 = System.nanoTime();
        double result = (double)( salida1 - entrada1);


        //segunda Inversa
        SequentialMatrix Prueba2 = new SequentialMatrix(150,150);
        long entrada2 = System.nanoTime();
        Prueba2.Inversa();
        long salida2 = System.nanoTime();
        double result1 = (double)( salida2 - entrada2);


        //tercera Inversa
        SequentialMatrix Prueba3 = new SequentialMatrix(200,200);
        long entrada3 = System.nanoTime();
        Prueba3.Inversa();
        long salida3 = System.nanoTime();
        double result2 = (double)( salida3 - entrada3);




        //Cuarta Inversa
        SequentialMatrix Prueba4 = new SequentialMatrix(75,75);
        long entrada4 = System.nanoTime();
        Prueba4.Inversa();
        long salida4 = System.nanoTime();
        double result3 = (double)( salida4 - entrada4);




















        // PRINTS

        //1er Par
        System.out.println("El programa toma en realizarse  "+ dif +" nanosecs ");

        //2do Par
        System.out.println("El programa toma en realizarse  "+ dif2 +" nanosecs ");

        //3er Par
        System.out.println("El programa toma en realizarse  "+ dif3 +" nanosecs ");

        //4to Par
        System.out.println("El programa toma en realizarse  "+ dif4 +" nanosecs ");

        System.out.println( result3 + " " + result + " " + result1 + " " + result2 );





    }
}
