package base;

import base.Matrix;

public class SequentialMatrix extends Matrix {

	public SequentialMatrix(int rDimension, int cDimension) {
		super(rDimension, cDimension);
		// TODO Auto-generated constructor stub
	}

	@Override
	public double[][] multiply(Matrix secondMatrix)
	{
		int cdimen = getColumnDimension();
		double[][] resultMatrix = new double[this.columnDimension][secondMatrix.getRowDimension()];
		for( int i =0; i<cdimen; i++)
			for(int j = 0; j<cdimen;j++){

				double multi = 0;
				for(int k=0;k<cdimen;k++)
					multi= multi + this.matrixData [i][k] * secondMatrix.matrixData [k][j];

				resultMatrix[i][j]= multi;
			}


		return null;
	}
	//Matriz Inversa
	public double[][] Inversa (){
		int cdimen = getColumnDimension();
		int i,j,k;
		double rango;
		double [][] identity= new double[cdimen][2*cdimen];


		for (i =0; i<cdimen; i++) {
			for ( j = 0; j < cdimen; j++) {
				identity[i][j]=this.matrixData[i][j];
				if (i == j) {
					identity[i][j + cdimen] = 1;
				} else {

					identity[i][j + cdimen] = 0;
				}
			}
		}

		// Reduccion Gaussiana
		for(i=0; i< cdimen;i++){
			for(j=0;j<cdimen;j++){
				if(i!=j){
				rango = identity[j][i]/identity[i][i];
				for(k=0;k<2*cdimen;k++){
					identity[j][k]= identity[j][k] - rango*identity[i][k];
					}
				}
			}

		}
		for(i=0;i<cdimen;i++) {
			for (j = cdimen + 1; j < 2 * cdimen; j++) {
				identity[i][j]= identity[i][j] / identity[i][i];
			}
		}

	return null;
	}


}
